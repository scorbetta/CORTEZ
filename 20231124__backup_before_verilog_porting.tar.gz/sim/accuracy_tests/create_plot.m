% Load data
data = load('data.csv');

fig1 = figure;
figure(fig1);

fig2 = figure;
figure(fig2);
hold all;
grid on;
xlabel('Iteration');
ylabel('F(x)');

for width=16:2:24
    indexes = find(data(:,1) == width);
    data_in = data(indexes,:);

    % Plot histogram
    figure(fig1);
    switch width
        case 16
            lb = 1;
        case 18
            lb = 3;
        case 20
            lb = 5;
        case 22
            lb = 8;
        case 24
            lb = 10;
    end

    ub = lb + 1;
    subplot(2,6,lb:ub);
    hist(data_in(:,3));
    grid on;
    xlim([0,1000]);
    set(gca,'xtick',[0:250:1000]);
    title(sprintf('<%d,%d>', width, width-3));

    if width == 16
        xlabel('Iteration');
        ylabel('Occurrences');
    end

    % Plot CDF
    cdf = zeros(1000,1);
    for idx=1:1:1000
        jndexes = find(data_in(:,3) == (idx-1));
        if !isempty(jndexes)
            cdf(data_in(jndexes,3)+1) = 1;
        end
    end
    figure(fig2);
    plot([1:1:1000], cumsum(cdf)./sum(cdf));
end

figure(fig1);
print -dpng hist.png;
close;

figure(fig2);
legend(sprintf('<%d,%d>', 16, 13),sprintf('<%d,%d>', 18, 15),sprintf('<%d,%d>', 20, 17),sprintf('<%d,%d>', 22, 19),sprintf('<%d,%d>', 24, 21),'location','southeast');
print -dpng cdf.png;
close;

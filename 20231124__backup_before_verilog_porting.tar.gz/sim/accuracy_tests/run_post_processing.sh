#!/usr/bin/bash

# Run post-processing over accuracy tests results

OFILE=${PWD}/data.csv
echo -n "" > ${OFILE}

pushd logs >/dev/null
    for file in $( ls NETWORK_*.runlog )
    do
        width=$( echo ${file} | cut -d '_' -f 2 )
        frac_bits=$( echo ${file} | cut -d '_' -f 3 )
        errline=$( grep "^Results mismatch" ${file} )
        if [ ! "${errline}" == "" ]
        then
            errloc=$( echo "${errline}" | cut -d '=' -f 2 | cut -d ',' -f 1 )
            echo "${width},${frac_bits},${errloc}" >> ${OFILE}
        fi
    done
popd >/dev/null

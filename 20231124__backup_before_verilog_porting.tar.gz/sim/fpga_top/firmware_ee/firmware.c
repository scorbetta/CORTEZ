#include <stdint.h>

// grogu utilities
#include "cortez_regpool_reg_defines.h"
#include "cortez_regpool_reg_offsets.h"

// Utilities
#define CORTEZ_WRITE_IO(addr,val) *((uint32_t *)(addr)) = val;
#define CORTEZ_READ_IO(addr,var) var = *((volatile uint32_t *)(addr));

// LEDs driver
#define LEDS_BASE   0x000b0000
// Peripheral memory
#define CORE_BASE   0x000c0000

void main()
{
    uint8_t leds_reg;
    CORTEZ_CORE_CTRL_reg_t ctrl_reg;

    // LEDs are initially switched off
    leds_reg = 0x0;
    CORTEZ_WRITE_IO(LEDS_BASE, leds_reg);

    // Initialize core peripheral
    #include "cortez_init.i"

    // Additionals
    ctrl_reg.value = 0;
    ctrl_reg.fields.RESET = 1;
    CORTEZ_WRITE_IO((CORE_BASE + (CORTEZ_CORE_CTRL_OFFSET << 2)), ctrl_reg.value);
    ctrl_reg.fields.RESET = 0;
    ctrl_reg.fields.CFG_DONE = 1;
    CORTEZ_WRITE_IO((CORE_BASE + (CORTEZ_CORE_CTRL_OFFSET << 2)), ctrl_reg.value);

    leds_reg = 0x1;
    CORTEZ_WRITE_IO(LEDS_BASE, leds_reg);

    // That's all folks!
    while(1) { }
}
